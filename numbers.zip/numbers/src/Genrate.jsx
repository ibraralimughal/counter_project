import { useState } from "react";

function Genrate() {

    let [count,setCount] = useState(0)

    let gen = ()=>{
        let ran = Math.round(Math.random() * 100);
        setCount(ran)
    }

    return(
        <>
        <h1>Hello</h1>
        <h2>{count}</h2>
        <button onClick={gen}>Genrate Number</button>
        </>
    )
}

export default Genrate;