import { useEffect,useState } from "react"

function Getapi(){

    let url = "https://jsonplaceholder.typicode.com/posts"

    let [datas,setDatas] = useState()

    useEffect(()=>{
     
        let data = async ()=>{
            let call = await fetch(url)
            let res = await call.json()
            
        }
 
    },[])



    return(

        <>
            {/* <h1>{datas}</h1>
            <button onClick={data}>Get Data</button> */}

            <ul>
                {datas.map((element)=>{
                    {
                        <li>
                            {element}
                        </li>
                    }
                })}
            </ul>
        </>
    )
}

export default Getapi