// import Genrate from "./Genrate";
import Getapi from "./Getapi";
function App() {
  return (
    <>
      {/* <Genrate></Genrate> */}
      <Getapi></Getapi>
    </>
  );
}

export default App;
